from flask import*
app = Flask(__name__)

@app.route("/login")
def login():
	return render_template("login.html")
	
@app.route("/register")
def register():
	return render_template("register.html")

@app.route("/buliding")
def buliding():
	return render_template("buliding.html")

@app.route("/floor")
def floor():
	return render_template("floor.html")


if __name__=="__main__":
	app.run()
	
